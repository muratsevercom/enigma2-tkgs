# -*- coding: utf-8 -*-
import os

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import NumberActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.ProgressBar import ProgressBar
from Components.AVSwitch import iAVSwitch
from Components.ConfigList import ConfigList
from Components.config import (
    config, configfile, ConfigInteger, ConfigSelection, ConfigSubsection,
    getConfigListEntry, KEY_LEFT, KEY_RIGHT, KEY_0,
)
from enigma import eConsoleAppContainer, eServiceReference, getDesktop, eDVBVolumecontrol, eTimer

try:
    _  # noqa: F821
except NameError:
    def _(txt):
        return txt

PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
ENGINE_SCRIPT = os.path.join(PLUGIN_PATH, "tkgs_engine.py")
if not os.path.exists(ENGINE_SCRIPT):
    # Kurulum sonrasi kaynak .py silinip yerine .pyc birakilmis olabilir
    # (bkz. paket postinst betigi). Python3, derlenmis bir .pyc dosyasini
    # da dogrudan komut satirindan calistirabilir.
    _engine_pyc = os.path.join(PLUGIN_PATH, "tkgs_engine.pyc")
    if os.path.exists(_engine_pyc):
        ENGINE_SCRIPT = _engine_pyc

if not hasattr(config.plugins, "tkgsautolcn"):
    config.plugins.tkgsautolcn = ConfigSubsection()
    config.plugins.tkgsautolcn.frequency = ConfigInteger(default=12380, limits=(3000, 14000))
    config.plugins.tkgsautolcn.polarization = ConfigSelection(
        default="V",
        choices=[("V", _("Dikey (V)")), ("H", _("Yatay (H)"))],
    )
    config.plugins.tkgsautolcn.symbolrate = ConfigInteger(default=27500, limits=(1000, 45000))

STAGE_LABELS = {
    "lamedb": _("Kanal veritabanı okunuyor..."),
    "zap_check": _("Mevcut kanal kontrol ediliyor..."),
    "zapping": _("TKGS güncelleme frekansına geçiliyor..."),
    "tuner_lock": _("Tuner kilitleniyor..."),
    "no_tkgs_freq": _("UYARI: Belirtilen frekans cihazınızda bulunamadı, mevcut kanaldan deneniyor..."),
    "capturing": _("TKGS verisi taranıyor..."),
    "zap_back": _("Önceki izlediğiniz kanala geri dönülüyor..."),
    "parsing": _("Kanal listesi oluşturuluyor..."),
    "writing": _("Bouquet dosyası yazılıyor..."),
    "reload": _("Arayüz yenileniyor..."),
}


class TKGSScan(Screen):
    def __init__(self, session):
        try:
            desktop = getDesktop(0)
            dw, dh = desktop.size().width(), desktop.size().height()
        except Exception:
            dw, dh = 1920, 1080
        PANEL_W, PANEL_H = 940, 700
        BORDER = 3
        bx = max(0, (dw - PANEL_W) // 2)
        by = max(0, (dh - PANEL_H) // 2)

        ACCENT = "#c9971f"
        PANEL_BG = "#0c0c0c"
        TEXT_WHITE = "#ffffff"

        HEADER_H = 50
        content_x = 24
        content_w = PANEL_W - 2 * content_x

        settings_title_y = HEADER_H + 14
        settings_list_y = settings_title_y + 26
        SETTINGS_ROW_H = 32
        settings_list_h = SETTINGS_ROW_H * 3  # frekans / polarizasyon / SR
        status_y = settings_list_y + settings_list_h + 18
        progress_y = status_y + 38
        progress_text_y = progress_y + 32
        found_title_y = progress_text_y + 34
        found_list_y = found_title_y + 30
        keys_y = PANEL_H - 50
        found_list_h = keys_y - found_list_y - 14

        self.skin = f"""
        <screen name="TKGSScan" position="0,0" size="{dw},{dh}" title="TKGS Otomatik Kanal Güncelleme by Murat SEVER" backgroundColor="#000000" transparent="0" flags="wfNoBorder">
            <widget name="frame_border" position="{bx - BORDER},{by - BORDER}" size="{PANEL_W + 2 * BORDER},{PANEL_H + 2 * BORDER}" backgroundColor="{ACCENT}" transparent="0" />
            <widget name="frame_bg" position="{bx},{by}" size="{PANEL_W},{PANEL_H}" backgroundColor="{PANEL_BG}" transparent="0" />
            <widget name="header" position="{bx},{by}" size="{PANEL_W},{HEADER_H - 2}" font="Regular;28" halign="center" valign="center" foregroundColor="{ACCENT}" backgroundColor="{PANEL_BG}" transparent="0" />
            <widget name="header_divider" position="{bx + content_x},{by + HEADER_H}" size="{content_w},2" backgroundColor="{ACCENT}" transparent="0" />
            <widget name="settings_title" position="{bx + content_x},{by + settings_title_y}" size="{content_w},22" font="Regular;18" foregroundColor="#999999" backgroundColor="{PANEL_BG}" transparent="0" />
            <widget name="settings_list" position="{bx + content_x},{by + settings_list_y}" size="{content_w},{settings_list_h}" itemHeight="{SETTINGS_ROW_H}" font="Regular;20" backgroundColor="{PANEL_BG}" foregroundColor="{TEXT_WHITE}" backgroundColorSelected="#2a2205" foregroundColorSelected="{ACCENT}" transparent="0" transparentSelected="0" />
            <widget name="status" position="{bx + content_x},{by + status_y}" size="{content_w},30" font="Regular;24" valign="center" backgroundColor="{PANEL_BG}" foregroundColor="{TEXT_WHITE}" transparent="0" />
            <widget name="progress" position="{bx + content_x},{by + progress_y}" size="{content_w},26" borderWidth="1" backgroundColor="{PANEL_BG}" foregroundColor="#1f771f" />
            <widget name="progress_text" position="{bx + content_x},{by + progress_text_y}" size="{content_w},25" font="Regular;20" halign="center" valign="center" backgroundColor="{PANEL_BG}" foregroundColor="{TEXT_WHITE}" transparent="0" />
            <widget name="found_title" position="{bx + content_x},{by + found_title_y}" size="{content_w},25" font="Regular;20" foregroundColor="#999999" backgroundColor="{PANEL_BG}" transparent="0" />
            <widget name="found_list" position="{bx + content_x},{by + found_list_y}" size="{content_w},{found_list_h}" scrollbarMode="showNever" itemHeight="28" font="Regular;20" backgroundColor="{PANEL_BG}" foregroundColor="{TEXT_WHITE}" backgroundColorSelected="{PANEL_BG}" foregroundColorSelected="{TEXT_WHITE}" transparent="0" transparentSelected="0" />
            <widget name="key_red" position="{bx + content_x},{by + keys_y}" size="200,36" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" foregroundColor="{TEXT_WHITE}" transparent="0" />
            <widget name="key_green" position="{bx + PANEL_W - content_x - 200},{by + keys_y}" size="200,36" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" foregroundColor="{TEXT_WHITE}" transparent="0" />
        </screen>"""

        Screen.__init__(self, session)
        self.setTitle(_("TKGS Otomatik Kanal Güncelleme by Murat SEVER"))
        self.saved_service_ref = None
        self.restored_playback = False
        try:
            cur = self.session.nav.getCurrentlyPlayingServiceReference()
            self.saved_service_ref = cur and cur.toString()
        except Exception:
            pass
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.av_blanked = False
        try:
            iAVSwitch.setInput("SCART")
            self.av_blanked = True
        except Exception:
            pass
        self.muted_by_us = False
        self.ensureMuted()
        self.muteTimer = eTimer()
        try:
            self.muteTimer_conn = self.muteTimer.timeout.connect(self.ensureMuted)
        except AttributeError:
            self.muteTimer.callback.append(self.ensureMuted)
        self.muteTimer.start(250, False)

        self["frame_border"] = Label("")
        self["frame_bg"] = Label("")
        self["header"] = Label(_("TKGS Otomatik Kanal Güncelleme by Murat SEVER"))
        self["header_divider"] = Label("")
        self["settings_title"] = Label(_("Tarama ayarları (YUKARI/AŞAĞI seç, SOL/SAĞ değiştir):"))
        self.cfg_list = [
            getConfigListEntry(_("Frekans (MHz)"), config.plugins.tkgsautolcn.frequency),
            getConfigListEntry(_("Polarizasyon"), config.plugins.tkgsautolcn.polarization),
            getConfigListEntry(_("Sembol Oranı (kSym/s)"), config.plugins.tkgsautolcn.symbolrate),
        ]
        self["settings_list"] = ConfigList(self.cfg_list)
        self["status"] = Label(_("Ayarları düzenleyin, taramayı başlatmak için YEŞİL ya da OK tuşuna basın."))
        self["progress"] = ProgressBar()
        self["progress"].setRange((0, 100))
        self["progress_text"] = Label("0 / 20 sn  -  0 paket  -  0 kanal")
        self["found_title"] = Label(_("Bulunan kanallar (LCN sırasıyla):"))
        self["found_list"] = MenuList([])
        self["key_red"] = Label(_("Çıkış"))
        self["key_green"] = Label(_("Başlat"))
        self["actions"] = NumberActionMap(["SetupActions", "ColorActions", "NumberActions"], {
            "cancel": self.cancelPressed,
            "red": self.cancelPressed,
            "green": self.greenPressed,
            "ok": self.greenPressed,
            "up": self.keyUp,
            "down": self.keyDown,
            "left": self.keyLeft,
            "right": self.keyRight,
            "1": self.keyNumberGlobal,
            "2": self.keyNumberGlobal,
            "3": self.keyNumberGlobal,
            "4": self.keyNumberGlobal,
            "5": self.keyNumberGlobal,
            "6": self.keyNumberGlobal,
            "7": self.keyNumberGlobal,
            "8": self.keyNumberGlobal,
            "9": self.keyNumberGlobal,
            "0": self.keyNumberGlobal,
        }, -1)

        self.found_items = []
        self.started = False
        self.finished = False
        self.failed = False
        self.outbuf = ""

        self.container = eConsoleAppContainer()
        self.container.appClosed.append(self.processFinished)
        self.container.dataAvail.append(self.dataAvail)
        self.onClose.append(self.cleanup)
        self.onLayoutFinish.append(self.layoutFinished)

    def layoutFinished(self):
        try:
            self["found_list"].instance.setSelectionEnable(0)
        except Exception:
            pass
    def configEditable(self):
        return not self.started or self.finished or self.failed

    def keyUp(self):
        if self.configEditable():
            try:
                self["settings_list"].instance.moveSelection(self["settings_list"].instance.moveUp)
            except Exception:
                pass

    def keyDown(self):
        if self.configEditable():
            try:
                self["settings_list"].instance.moveSelection(self["settings_list"].instance.moveDown)
            except Exception:
                pass

    def keyLeft(self):
        if self.configEditable():
            try:
                self["settings_list"].handleKey(KEY_LEFT)
            except Exception:
                pass

    def keyRight(self):
        if self.configEditable():
            try:
                self["settings_list"].handleKey(KEY_RIGHT)
            except Exception:
                pass

    def keyNumberGlobal(self, number):
        if self.configEditable():
            try:
                self["settings_list"].handleKey(KEY_0 + number)
            except Exception:
                pass

    def ensureMuted(self):
        try:
            vc = eDVBVolumecontrol.getInstance()
            if not vc.isMuted():
                vc.volumeMute()
                self.muted_by_us = True
        except Exception:
            pass

    # --- surec baslatma / veri okuma ---

    def greenPressed(self):
        if not self.started:
            self.startScan()
        elif self.finished or self.failed:
            self.restartScan()

    def restartScan(self):
        self.found_items = []
        self["found_list"].setList([])
        self.finished = False
        self.failed = False
        self.outbuf = ""
        self["progress"].setValue(0)
        self["progress_text"].setText("0 / 20 sn  -  0 paket  -  0 kanal")
        self.startScan()

    def startScan(self):
        self.started = True
        self["status"].setText(_("TKGS verisi taranıyor, lütfen bekleyin..."))
        self["key_green"].setText("")
        self["key_red"].setText(_("İptal"))
        freq = config.plugins.tkgsautolcn.frequency.value
        pol = config.plugins.tkgsautolcn.polarization.value
        sr = config.plugins.tkgsautolcn.symbolrate.value
        try:
            config.plugins.tkgsautolcn.frequency.save()
            config.plugins.tkgsautolcn.polarization.save()
            config.plugins.tkgsautolcn.symbolrate.save()
            configfile.save()
        except Exception:
            pass

        cmd = "python3 %s %d %s %d" % (ENGINE_SCRIPT, freq, pol, sr)
        if self.container.execute(cmd):
            self.processFinished(-1)

    def dataAvail(self, data):
        try:
            if isinstance(data, bytes):
                data = data.decode("utf-8", "ignore")
        except Exception:
            data = str(data)
        self.outbuf += data
        while "\n" in self.outbuf:
            line, self.outbuf = self.outbuf.split("\n", 1)
            self.handleLine(line.strip())

    def handleLine(self, line):
        if not line:
            return
        if line.startswith("TKGS_PROGRESS "):
            parts = line.split(" ")
            if len(parts) >= 4:
                try:
                    elapsed = float(parts[1])
                    total = float(parts[2])
                    packets = int(parts[3])
                    pct = int((elapsed / total) * 100) if total > 0 else 0
                    pct = max(0, min(100, pct))
                    self["progress"].setValue(pct)
                    self["progress_text"].setText(
                        "%d / %d sn  -  %d paket  -  %d kanal" % (int(elapsed), int(total), packets, len(self.found_items))
                    )
                    self.ensureMuted()
                except ValueError:
                    pass
        elif line.startswith("TKGS_FOUND "):
            parts = line.split(" ", 3)
            if len(parts) >= 4:
                lcn, _sid_hex, name = parts[1], parts[2], parts[3]
                self.found_items.append("%-5s %s" % (lcn, name))
                self["found_list"].setList(self.found_items)
                self["found_list"].moveToIndex(len(self.found_items) - 1)
        elif line.startswith("TKGS_STAGE "):
            stage = line[len("TKGS_STAGE "):].strip()
            self["status"].setText(STAGE_LABELS.get(stage, stage))
            self.ensureMuted()
        elif line.startswith("TKGS_ERROR "):
            self.failed = True
            msg = line[len("TKGS_ERROR "):].strip()
            self["status"].setText(_("HATA: ") + msg)
            self["key_red"].setText(_("Kapat"))
            self["key_green"].setText(_("Yeniden Tara"))
        elif line.startswith("TKGS_DONE "):
            parts = line.split(" ")
            if len(parts) >= 3:
                try:
                    total = int(parts[1])
                    matched = int(parts[2])
                    self["progress"].setValue(100)
                    self["status"].setText(
                        _("Tamamlandı: %d kanal bulundu, %d tanesi eşleşti.") % (total, matched)
                    )
                except ValueError:
                    self["status"].setText(_("Tamamlandı."))
            self.finished = True
            self["key_red"].setText(_("Kapat"))
            self["key_green"].setText(_("Yeniden Tara"))

    # --- surec bitisi / iptal / kapama ---

    def processFinished(self, retval):
        if not self.started:
            return
        if not self.finished and not self.failed:
            self.failed = True
            self["status"].setText(
                _("İşlem beklenmedik şekilde sonlandı (çıkış kodu: %d).") % retval
            )
        self["key_red"].setText(_("Kapat"))
        self["key_green"].setText(_("Yeniden Tara"))

    def cancelPressed(self):
        if not self.started or self.finished or self.failed:
            self.close()
            return
        self.session.openWithCallback(
            self.cancelConfirmed, MessageBox,
            _("Taramayı iptal etmek istiyor musunuz? (Cihaz izlediğiniz kanala geri dönemeyebilir.)"),
            MessageBox.TYPE_YESNO
        )

    def cancelConfirmed(self, confirmed):
        if confirmed:
            try:
                self.container.kill()
            except Exception:
                pass
            self.close()

    def cleanup(self):
        try:
            self.container.appClosed.remove(self.processFinished)
        except Exception:
            pass
        try:
            self.container.dataAvail.remove(self.dataAvail)
        except Exception:
            pass
        if not self.finished and not self.failed:
            try:
                self.container.kill()
            except Exception:
                pass
        try:
            self.muteTimer.stop()
        except Exception:
            pass
        if self.av_blanked:
            try:
                iAVSwitch.setInput("ENCODER")
            except Exception:
                pass
            self.av_blanked = False
        if not self.restored_playback and self.saved_service_ref:
            try:
                self.session.nav.playService(eServiceReference(self.saved_service_ref))
            except Exception:
                pass
            self.restored_playback = True
            try:
                config.tv.lastservice.value = self.saved_service_ref
                config.tv.lastservice.save()
                configfile.save()
            except Exception:
                pass
        if self.muted_by_us:
            try:
                eDVBVolumecontrol.getInstance().volumeUnMute()
            except Exception:
                pass
            self.muted_by_us = False
