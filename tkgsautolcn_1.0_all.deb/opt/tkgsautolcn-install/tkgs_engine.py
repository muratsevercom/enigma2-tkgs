import os
import ctypes
import fcntl
import select
import time
import sys
import json
import base64
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET

# --- TKGS PARSE SUNUCUSU ---
# Asil ayristirma mantigi artik cihazda degil, bu adresteki sunucuda calisiyor.
SERVER_URL = "https://tkgs.muratsever.com/parse.php"
API_KEY = "9005b9694a49b3ffaea4b8e9b9741bbc09fdb16830664c2a1ab7a5043bffbfb3"  # parse.php'deki API_KEY ile ayni olmali


def remote_extract_channels(sections):
    """Ham demux sectionlarini sunucuya gonderip parse edilmis sonucu alir.
    Asil TKGS tablo ayristirma mantigi burada DEGIL, sunucuda calisir."""
    try:
        payload = json.dumps({
            "sections": [base64.b64encode(bytes(s)).decode("ascii") for s in sections]
        }).encode("utf-8")
        req = urllib.request.Request(
            SERVER_URL,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "X-TKGS-Key": API_KEY,
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            result = json.loads(resp.read().decode("utf-8"))
        if not result.get("ok"):
            print(f"[!] Sunucu hatasi: {result.get('error', 'bilinmiyor')}")
            return {}, {}
        sid_to_name = {int(k): v for k, v in result.get("sid_to_name", {}).items()}
        lcn_to_sid = {int(k): int(v) for k, v in result.get("lcn_to_sid", {}).items()}
        return sid_to_name, lcn_to_sid
    except Exception as e:
        print(f"[!] Sunucuya baglanilamadi: {e}")
        return {}, {}


# --- AKILLI ZAP FONKSIYONLARI ---

def get_current_channel():
    try:
        req = urllib.request.urlopen("http://127.0.0.1/web/getcurrent", timeout=3)
        xml_data = req.read()
        root = ET.fromstring(xml_data)
        for service in root.iter('e2service'):
            ref = service.find('e2servicereference')
            if ref is not None and ref.text:
                return ref.text
    except Exception as e:
        print(f"[!] Mevcut kanal alinamadi (WebIf hatasi): {e}")
    return None


def zap_to_channel(sref):
    try:
        safe_ref = urllib.parse.quote(sref)
        urllib.request.urlopen(f"http://127.0.0.1/web/zap?sRef={safe_ref}", timeout=3)
        return True
    except Exception as e:
        print(f"[!] Zap yapilamadi: {e}")
        return False


def parse_real_tkgs_lcn(freq_mhz=None, pol=None, sr_ksym=None):
    if freq_mhz is None:
        freq_mhz = 12380
    if pol is None:
        pol = "V"
    if sr_ksym is None:
        sr_ksym = 27500
    pol = pol.upper()
    pol_code = "1" if pol == "V" else "0"

    lamedb_path = "/etc/enigma2/lamedb"
    if not os.path.exists(lamedb_path):
        print("Hata: lamedb dosyasi bulunamadi.")
        print("TKGS_ERROR lamedb dosyasi bulunamadi")
        return

    print(f">> Lamedb veritabani okunuyor ve {freq_mhz} {pol} {sr_ksym} frekansi araniyor...")
    print("TKGS_STAGE lamedb")
    with open(lamedb_path, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.read().splitlines()

    tkgs_ns, tkgs_tsid, tkgs_onid = None, None, None
    in_transponders = False
    current_tp_id = ""
    for line in lines:
        if line == "transponders":
            in_transponders = True
            continue
        if line == "end" and in_transponders:
            break
        if in_transponders:
            if ":" in line and line.count(":") >= 2 and not line.startswith("\t") and not line.startswith("s") and not line.startswith("p") and not line.startswith("c"):
                current_tp_id = line
            elif line.startswith("\ts") or line.startswith("s "):
                parts = line.strip().split()
                if len(parts) >= 2:
                    params = parts[1].split(":")
                    if len(params) >= 3 and params[0].startswith(str(freq_mhz)) and params[1].startswith(str(sr_ksym)) and params[2] == pol_code:
                        tp_parts = current_tp_id.split(":")
                        tkgs_ns = tp_parts[0].lstrip("0").lower() or "0"
                        tkgs_tsid = tp_parts[1].lstrip("0").lower() or "0"
                        tkgs_onid = tp_parts[2].lstrip("0").lower() or "0"
                        break

    sid_to_ref = {}
    tkgs_sref = None
    in_services = False
    for line in lines:
        if line == "services":
            in_services = True
            continue
        if line == "end" and in_services:
            break
        if in_services and ":" in line and not line.startswith("\t"):
            parts = line.split(":")
            if len(parts) >= 6:
                try:
                    sid_dec = int(parts[0], 16)
                    s_h = "{:X}".format(int(parts[0], 16))
                    ns_h = "{:X}".format(int(parts[1], 16))
                    tsid_h = "{:X}".format(int(parts[2], 16))
                    onid_h = "{:X}".format(int(parts[3], 16))
                    stype_dec = int(parts[4], 16)
                    stype_h = "{:X}".format(stype_dec)

                    ref = f"1:0:{stype_h}:{s_h}:{tsid_h}:{onid_h}:{ns_h}:0:0:0:"
                    if sid_dec not in sid_to_ref or "1A4" in ns_h.upper():
                        sid_to_ref[sid_dec] = ref

                    if tkgs_ns:
                        c_ns = parts[1].lstrip("0").lower() or "0"
                        c_tsid = parts[2].lstrip("0").lower() or "0"
                        c_onid = parts[3].lstrip("0").lower() or "0"
                        if c_ns == tkgs_ns and c_tsid == tkgs_tsid and c_onid == tkgs_onid:
                            if tkgs_sref is None:
                                tkgs_sref = ref
                except ValueError:
                    pass

    # --- AKILLI ZAP ISLEMI ---
    print("TKGS_STAGE zap_check")
    original_channel = get_current_channel()
    zapped = False
    if tkgs_sref:
        if original_channel != tkgs_sref:
            print(f">> TKGS guncelleme frekansina ({freq_mhz} {pol}) otomatik geciliyor...")
            print("TKGS_STAGE zapping")
            if zap_to_channel(tkgs_sref):
                zapped = True
                print(">> Tunerin kilitlenmesi bekleniyor (3 saniye)...")
                print("TKGS_STAGE tuner_lock")
                time.sleep(3.0)
        else:
            print(">> Zaten dogru frekanstasiniz, zap yapilmiyor.")
    else:
        print(f"[!] UYARI: Cihazinizda {freq_mhz} {pol} {sr_ksym} frekansina ait kanal bulunamadi!")
        print("[!] Veri cekilemeyebilir, mevcut kanaldan okuma deneniyor...")
        print("TKGS_STAGE no_tkgs_freq")

    # --- DEMUX (VERI OKUMA) ISLEMI ---
    demux_path = "/dev/dvb/adapter0/demux0"
    if not os.path.exists(demux_path):
        print("Hata: %s bulunamadi." % demux_path)
        print(f"TKGS_ERROR {demux_path} bulunamadi")
        sys.exit(1)
    demux_fd = os.open(demux_path, os.O_RDWR)

    class DmxFilter(ctypes.Structure):
        _fields_ = [("filter", ctypes.c_uint8 * 16), ("mask", ctypes.c_uint8 * 16), ("mode", ctypes.c_uint8 * 16)]

    class DmxParams(ctypes.Structure):
        _fields_ = [("pid", ctypes.c_uint16), ("filter", DmxFilter), ("timeout", ctypes.c_uint32), ("flags", ctypes.c_uint32)]

    p = DmxParams()
    p.pid = 8181
    p.flags = 1
    for i in range(16):
        p.filter.filter[i], p.filter.mask[i], p.filter.mode[i] = 0, 0, 0
    fcntl.ioctl(demux_fd, 0x403c6f2b, p)
    fcntl.ioctl(demux_fd, 0x00006f29)

    sections = []

    TOTAL_WINDOW = 20.0
    PARSE_INTERVAL = 4.0  # sunucuya kac saniyede bir ara sonuc icin istek atilacak
    print(f">> TKGS verisi canli yayindan okunuyor ({TOTAL_WINDOW:.0f} saniye)...")
    print("TKGS_STAGE capturing")

    start_time = time.time()
    end_time = start_time + TOTAL_WINDOW
    last_progress = time.time()
    last_parse = time.time()
    seen_lcns = set()
    while time.time() < end_time:
        ready = select.select([demux_fd], [], [], 1.0)
        if ready[0]:
            try:
                data = os.read(demux_fd, 4096)
                if len(data) > 3:
                    sections.append(data)
            except OSError:
                pass
        now = time.time()
        if now - last_progress >= 1.0:
            last_progress = now
            elapsed = now - start_time
            print(f"TKGS_PROGRESS {elapsed:.1f} {TOTAL_WINDOW:.1f} {len(sections)}")
            sys.stdout.flush()
        # Akiskan gorunum: birikmis veriyi belirli araliklarla sunucuya
        # gonderip yeni bulunan kanallari kademeli olarak listeye ekliyoruz.
        if sections and now - last_parse >= PARSE_INTERVAL:
            last_parse = now
            preview_names, preview_lcns = remote_extract_channels(sections)
            for lcn in sorted(preview_lcns.keys()):
                if lcn not in seen_lcns:
                    seen_lcns.add(lcn)
                    sid = preview_lcns[lcn]
                    name = preview_names.get(sid, "?")
                    print(f"TKGS_FOUND {lcn} {sid:04X} {name}")
            sys.stdout.flush()

    fcntl.ioctl(demux_fd, 0x00006f2a)
    os.close(demux_fd)

    total_capture_time = time.time() - start_time
    print(f">> Yakalama suresi: {total_capture_time:.1f} sn.")

    # --- ISLEM BITINCE ESKI KANALA GERI DON ---
    if zapped and original_channel:
        print(">> Okuma bitti. Eski kanala geri donuluyor...")
        print("TKGS_STAGE zap_back")
        zap_to_channel(original_channel)

    print(f">> Toplam {len(sections)} adet ham veri paketi yakalandi.")
    if len(sections) == 0:
        print("HATA: TKGS verisi gelmedi. Sinyal yok veya yanlis frekans.")
        print("TKGS_ERROR TKGS verisi gelmedi (sinyal yok veya yanlis frekans)")
        return

    # --- VERI ISLEME VE BUKET YAZMA ---
    print("TKGS_STAGE parsing")
    print("TKGS_STAGE server_parsing")
    sid_to_name, lcn_to_sid = remote_extract_channels(sections)

    channels = sorted([(lcn, sid, sid_to_name[sid]) for lcn, sid in lcn_to_sid.items()])

    # Kapanis taramasinda kacirilmis olabilecek (henuz TKGS_FOUND ile
    # basilmamis) kanallar varsa onlari da tamamla.
    for lcn, sid, name in channels:
        if lcn not in seen_lcns:
            seen_lcns.add(lcn)
            print(f"TKGS_FOUND {lcn} {sid:04X} {name}")
    sys.stdout.flush()

    print("TKGS_STAGE writing")
    bouquet_path = "/etc/enigma2/userbouquet.tkgs_auto.tv"
    with open(bouquet_path, "w", encoding="utf-8") as f:
        f.write("#NAME Türksat TKGS\n")
        matched_count = 0
        already_written_sids = set()
        for lcn, sid, name in channels:
            if sid in already_written_sids:
                continue
            if sid in sid_to_ref:
                f.write(f"#SERVICE {sid_to_ref[sid]}\n")
                f.write(f"#DESCRIPTION {name}\n")
                matched_count += 1
                already_written_sids.add(sid)
            else:
                f.write(f"#SERVICE 1:0:1:0:0:0:0:0:0:0:http%3a//dummy/{name.replace(' ', '_')}\n")
                f.write(f"#DESCRIPTION {name}\n")
                already_written_sids.add(sid)

    tv_bouquets_path = "/etc/enigma2/bouquets.tv"
    if os.path.exists(tv_bouquets_path):
        with open(tv_bouquets_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        entry = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.tkgs_auto.tv" ORDER BY bouquet\n'
        if entry not in ''.join(lines):
            with open(tv_bouquets_path, "w", encoding="utf-8") as f:
                f.writelines(lines + [entry])

    print(f"\n[+] Islem Basarili!")
    print(f">> TKGS'de bulunan {len(channels)} kanalin {matched_count} tanesi cihazinizdaki frekanslarla eslestirildi.")
    print(">> Arayuz yenileniyor...")
    print("TKGS_STAGE reload")
    os.system("wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1")
    print(f"TKGS_DONE {len(channels)} {matched_count}")


if __name__ == "__main__":
    _freq_arg, _pol_arg, _sr_arg = None, None, None
    if len(sys.argv) >= 4:
        try:
            _freq_arg = int(sys.argv[1])
            _pol_arg = sys.argv[2]
            _sr_arg = int(sys.argv[3])
        except ValueError:
            _freq_arg, _pol_arg, _sr_arg = None, None, None
    parse_real_tkgs_lcn(_freq_arg, _pol_arg, _sr_arg)
