from Plugins.Plugin import PluginDescriptor

try:
    _  # noqa: F821
except NameError:
    def _(txt):
        return txt


def main(session, **kwargs):
    from .TKGSScan import TKGSScan
    session.open(TKGSScan)


def Plugins(**kwargs):
    description = _("Türksat TKGS verisiyle kanal listesini/LCN sırasını otomatik günceller")
    return [
        PluginDescriptor(
            name=_("TKGS Otomatik Kanal Güncelleme"),
            description=description,
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            icon="plugin.png",
            fnc=main,
        ),
        PluginDescriptor(
            name=_("TKGS Otomatik Kanal Güncelleme"),
            description=description,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main,
        ),
    ]
