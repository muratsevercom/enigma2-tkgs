# -*- coding: utf-8 -*-
import errno
import fcntl
import os
import platform
import select
import struct
import threading

from .compat import clock

PID = 0x1FF5
TABLE = 0xA7


class Crc(object):
    POLY = 0x04C11DB7
    _table = None

    @classmethod
    def table(cls):
        if cls._table is None:
            rows = []
            for byte in range(256):
                acc = byte << 24
                for _bit in range(8):
                    acc = ((acc << 1) ^ cls.POLY) if acc & 0x80000000 else (acc << 1)
                    acc &= 0xFFFFFFFF
                rows.append(acc)
            cls._table = tuple(rows)
        return cls._table

    @classmethod
    def residue(cls, data):
        rows = cls.table()
        acc = 0xFFFFFFFF
        for byte in bytearray(data):
            acc = ((acc << 8) & 0xFFFFFFFF) ^ rows[(acc >> 24) ^ byte]
        return acc

    @classmethod
    def valid(cls, data):
        return cls.residue(data) == 0


class Packet(object):
    __slots__ = ("blob", "ext_id", "rev", "seq", "last_seq")

    def __init__(self, blob, ext_id, rev, seq, last_seq):
        self.blob, self.ext_id, self.rev, self.seq, self.last_seq = blob, ext_id, rev, seq, last_seq

    @property
    def body(self):
        return self.blob[8:len(self.blob) - 4]

    @classmethod
    def decode(cls, data, verify=True):
        buf = bytearray(data)
        if len(buf) < 0x0C or buf[0] != TABLE or (buf[1] & 0x80) == 0:
            return None
        if len(buf) != 3 + ((buf[1] & 0x0F) << 8 | buf[2]):
            return None
        if (buf[5] & 1) == 0 or buf[6] > buf[7]:
            return None
        if verify and not Crc.valid(buf):
            return None
        return cls(bytes(buf), buf[3] << 8 | buf[4], buf[5] >> 1 & 0x1F, buf[6], buf[7])


class Splitter(object):
    LIMIT = 65536

    def __init__(self):
        self.pending = bytearray()

    def clear(self):
        del self.pending[:]

    def push(self, chunk):
        buf = self.pending
        buf.extend(chunk)
        found = []
        cursor = 0
        while len(buf) - cursor >= 3:
            if buf[cursor] != TABLE or not buf[cursor + 1] & 0x80:
                cursor += 1
                continue
            size = 3 + (((buf[cursor + 1] & 0x0F) << 8) | buf[cursor + 2])
            if size < 0x0C:
                cursor += 1
                continue
            if len(buf) - cursor < size:
                break
            found.append(bytes(buf[cursor:cursor + size]))
            cursor += size
        del buf[:cursor]
        if len(buf) > self.LIMIT:
            self.clear()
        return found


class Assembler(object):
    def __init__(self, verify=True):
        self.verify = verify
        self.parts = {}
        self.dropped = 0
        self.repeats = 0
        self.fresh_at = 0.0

    def offer(self, data):
        pkt = Packet.decode(data, self.verify)
        if pkt is None:
            self.dropped += 1
            return False
        entry = self.parts.get(pkt.ext_id)
        if entry is None:
            entry = self.parts[pkt.ext_id] = [pkt.rev, pkt.last_seq, {}]
            self.fresh_at = clock()
        elif entry[0] != pkt.rev:
            if (pkt.rev - entry[0]) % 32 >= 16:
                self.dropped += 1
                return False
            entry[:] = [pkt.rev, pkt.last_seq, {}]
        elif entry[1] != pkt.last_seq:
            self.dropped += 1
            return False
        if pkt.seq in entry[2]:
            self.repeats += 1
            return False
        entry[2][pkt.seq] = pkt.blob
        return True

    def progress(self):
        return (sum(len(s[2]) for s in self.parts.values()),
                sum(s[1] + 1 for s in self.parts.values()))

    def done(self):
        return bool(self.parts) and all(len(s[2]) == s[1] + 1 for s in self.parts.values())

    def ordered(self):
        out = []
        for ext in sorted(self.parts):
            chunks = self.parts[ext][2]
            out.extend(chunks[i] for i in sorted(chunks))
        return out

    def revisions(self):
        return dict((ext, s[0]) for ext, s in self.parts.items())


def stitch(blobs, verify=True):
    ordered = sorted((p.ext_id, p.seq, p.body) for p in (Packet.decode(b, verify) for b in blobs) if p is not None)
    return b"".join(chunk for _, _, chunk in ordered)


def save(path, raws):
    with open(path, "wb") as handle:
        for raw in raws:
            handle.write(raw)


def restore_blobs(path):
    with open(path, "rb") as handle:
        return Splitter().push(handle.read())


class Ioctl(object):
    LAYOUT = struct.Struct("=H16s16s16s2xII")
    CHECK_CRC = 1
    IMMEDIATE = 4

    def __init__(self, machine=None):
        arch = (machine or platform.machine()).lower()
        legacy = arch.startswith(("mips", "ppc", "powerpc", "sparc", "parisc", "alpha"))
        self.size_bits = 13 if legacy else 14
        self.none_dir = 1 if legacy else 0
        self.write_dir = 4 if legacy else 1
        self.start = self.code(41)
        self.stop = self.code(42)
        self.filter = self.code(43, self.LAYOUT.size, True)
        self.buffer = self.code(45)

    def code(self, nr, size=0, write=False):
        direction = self.write_dir if write else self.none_dir
        return (direction << (16 + self.size_bits)) | (size << 16) | (ord("o") << 8) | nr

    def params(self, verify):
        flags = self.IMMEDIATE | (self.CHECK_CRC if verify else 0)
        return self.LAYOUT.pack(PID, struct.pack("B", TABLE), b"\xff", b"", 0, flags)

    @staticmethod
    def call(port, request, arg=0):
        try:
            return fcntl.ioctl(port, request, arg)
        except OverflowError:
            return fcntl.ioctl(port, request - (1 << 32) if request >= (1 << 31) else request, arg)

    def arm(self, port, verify):
        try:
            self.call(port, self.stop)
        except (OSError, IOError):
            pass
        try:
            self.call(port, self.buffer, 256 * 1024)
        except (OSError, IOError, TypeError):
            pass
        self.call(port, self.filter, self.params(verify))

    def disarm(self, port):
        try:
            self.call(port, self.stop)
        except (OSError, IOError, TypeError):
            pass


def demuxes(adapter=0, first=None):
    root = "/dev/dvb/adapter%d" % adapter
    paths = ["%s/demux%d" % (root, first)] if first is not None else []
    try:
        names = sorted(n for n in os.listdir(root) if n.startswith("demux"))
    except OSError:
        names = []
    for name in names:
        path = os.path.join(root, name)
        if path not in paths:
            paths.append(path)
    return paths


def _open(path):
    try:
        return os.open(path, os.O_RDWR | os.O_NONBLOCK)
    except OSError:
        return os.open(path, os.O_RDONLY | os.O_NONBLOCK)


class Grabber(threading.Thread):
    def __init__(self, paths, limit=60.0, idle=20.0, relax=25.0, calm=2.0, opener=None, arm=None):
        threading.Thread.__init__(self, name="MSTKGSGrabber")
        self.daemon = True
        self.paths = list(paths)
        self.limit = limit
        self.idle = idle
        self.relax = relax
        self.calm = calm
        self.opener = opener or _open
        self.ioctl = Ioctl()
        self.arm = arm or self.ioctl.arm
        self.halt = threading.Event()
        self.table = Assembler(True)
        self.verified = True
        self.fault = None
        self.over = False
        self.whole = False
        self.spent = 0.0
        self.source = None
        self.count = 0
        self.trail = []
        self.overflows = 0

    def abort(self):
        self.halt.set()

    def snapshot(self):
        have, total = self.table.progress()
        return {"have": have, "total": total, "elapsed": self.spent, "crc": self.verified,
                "count": self.count, "tables": len(self.table.parts)}

    def _attach(self):
        handles = {}
        for path in self.paths:
            try:
                port = self.opener(path)
            except (OSError, IOError) as exc:
                self.trail.append("acilamadi %s: %s" % (path, exc))
                continue
            try:
                self.arm(port, True)
            except (OSError, IOError) as exc:
                self.trail.append("filtre kurulamadi %s: %s" % (path, exc))
                os.close(port)
                continue
            self.trail.append("dinleniyor %s" % path)
            handles[port] = [path, Splitter()]
        return handles

    def _relax(self, handles):
        self.verified = False
        self.trail.append("CRC'siz moda gecildi (%.1f sn, %d/%d bolum)" % ((self.spent,) + self.table.progress()))
        old = self.table
        self.table = Assembler(False)
        for raw in old.ordered():
            self.table.offer(raw)
        for port, entry in handles.items():
            try:
                self.arm(port, False)
                entry[1].clear()
            except (OSError, IOError):
                pass

    def _drain(self, port, entry):
        for _round in range(0x20):
            try:
                piece = os.read(port, 0x2000)
            except (OSError, IOError) as exc:
                if exc.errno in (errno.EAGAIN, errno.EWOULDBLOCK, errno.EINTR):
                    return
                if exc.errno == errno.EOVERFLOW:
                    self.overflows += 1
                    entry[1].clear()
                    continue
                raise
            if not piece:
                return
            for raw in entry[1].push(piece):
                if self.table.offer(raw):
                    self.count += 1
                    self.source = entry[0]
                    self.last = clock()

    def run(self):
        handles = {}
        try:
            handles = self._attach()
            if not handles:
                self.fault = "Demux açılamadı (%s)." % ", ".join(self.paths)
                return
            begin = self.last = clock()
            relaxed = False
            while not self.halt.is_set():
                now = clock()
                self.spent = now - begin
                if self.spent > self.limit:
                    break
                if self.table.done() and now - self.table.fresh_at >= self.calm:
                    break
                if not self.table.parts and now - self.last > self.idle:
                    break
                if not relaxed and not self.table.done() and self.spent > self.relax:
                    relaxed = True
                    self._relax(handles)
                try:
                    ready = select.select(list(handles), [], [], 0.25)[0]
                except (OSError, IOError, ValueError, select.error) as exc:
                    if getattr(exc, "errno", None) == errno.EINTR or (exc.args and exc.args[0] == errno.EINTR):
                        continue
                    raise
                for ready_port in ready:
                    self._drain(ready_port, handles[ready_port])
            self.whole = self.table.done()
        except Exception as exc:
            self.fault = "%s: %s" % (type(exc).__name__, exc)
        finally:
            for port in handles:
                self.ioctl.disarm(port)
                try:
                    os.close(port)
                except OSError:
                    pass
            self.over = True
